package com.example.services

import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

class TtsSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isReady = false

    private var speechRate = 0.95f // Slightly reduced rate for clear Sinhala articulation
    private var speechPitch = 1.0f
    private var currentLanguage = "Sinhala"

    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    init {
        initializeEngine()
    }

    private fun initializeEngine() {
        // Explicitly prioritize Google TTS engine ("com.google.android.tts") for high-fidelity Sinhala neural voices
        try {
            tts = TextToSpeech(context.applicationContext, this, "com.google.android.tts")
        } catch (e: Exception) {
            Log.e("TtsSpeechManager", "Failed to initialize Google TTS engine, falling back to default", e)
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isReady = true

            // Set high-fidelity AudioAttributes for clear speech playback
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .build()
                tts?.setAudioAttributes(audioAttributes)
            }

            setLanguage(currentLanguage)
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(speechPitch)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {}
            })
        } else {
            Log.e("TtsSpeechManager", "TextToSpeech init failed with status: $status")
        }
    }

    fun setLanguage(lang: String) {
        currentLanguage = lang
        if (!isReady) return

        val isSinhala = lang.equals("Sinhala", ignoreCase = true) || lang.equals("si", ignoreCase = true) || lang.contains("සිංහල")
        val locale = if (isSinhala) {
            Locale("si", "LK")
        } else if (lang.equals("Tamil", ignoreCase = true) || lang.equals("ta", ignoreCase = true)) {
            Locale("ta", "LK")
        } else {
            Locale.US
        }

        var result = tts?.setLanguage(locale)
        if (isSinhala && (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)) {
            // Try generic Sinhala locale without country specifier
            result = tts?.setLanguage(Locale("si"))
        }

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.US
        } else {
            // Priority selection for high-fidelity Sinhala neural/high-quality voices
            selectHighFidelityNeuralVoice(locale, isSinhala)
        }
    }

    private fun selectHighFidelityNeuralVoice(targetLocale: Locale, isSinhala: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return

        try {
            val availableVoices = tts?.voices ?: return
            
            // Filter voices matching the language
            val matchingVoices = availableVoices.filter { voice ->
                voice.locale.language.equals(targetLocale.language, ignoreCase = true)
            }

            if (matchingVoices.isNotEmpty()) {
                // Score voices to select high-fidelity / neural voice (e.g. WaveNet, Neural, Very High Quality)
                val bestVoice = matchingVoices.maxByOrNull { voice ->
                    var score = 0
                    if (voice.quality == Voice.QUALITY_VERY_HIGH) score += 20
                    if (voice.quality == Voice.QUALITY_HIGH) score += 10
                    
                    val voiceName = voice.name.lowercase()
                    if (voiceName.contains("neural") || voiceName.contains("wavenet") || voiceName.contains("network")) {
                        score += 30
                    }
                    if (voiceName.contains("si-lk") || voiceName.contains("si_lk")) {
                        score += 15
                    }
                    if (voice.features?.contains("networkRetrievalRequired") == false) {
                        score += 5 // Local offline voice preference if network unavailable
                    }
                    score
                }

                if (bestVoice != null) {
                    tts?.voice = bestVoice
                    Log.d("TtsSpeechManager", "Selected high-fidelity voice: ${bestVoice.name} for locale ${targetLocale.language}")
                }
            }
        } catch (e: Exception) {
            Log.e("TtsSpeechManager", "Error selecting neural voice", e)
        }
    }

    fun updateParams(speed: Float, pitch: Float, language: String) {
        this.speechRate = speed
        this.speechPitch = pitch
        this.currentLanguage = language

        tts?.setSpeechRate(speed)
        tts?.setPitch(pitch)
        setLanguage(language)
    }

    fun speak(text: String, queueMode: Int = TextToSpeech.QUEUE_FLUSH) {
        if (isReady && text.isNotBlank()) {
            val sanitizedText = sanitizeForSinhalaSpeech(text)
            
            val params = Bundle()
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                tts?.speak(sanitizedText, queueMode, params, "UTTERANCE_${System.currentTimeMillis()}")
            } else {
                @Suppress("DEPRECATION")
                tts?.speak(sanitizedText, queueMode, null)
            }
        }
    }

    private fun sanitizeForSinhalaSpeech(rawText: String): String {
        return rawText
            // Remove markdown formatting symbols
            .replace(Regex("[*#_~`>\\[\\]()]"), " ")
            // Remove technical tags like [Cloud Vision OCR] or [නොබැඳි TFLite] for smoother audio output
            .replace(Regex("\\[.*?\\]"), "")
            // Normalize multi-spaces
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun stop() {
        tts?.stop()
    }

    // Tactile Haptic Feedback Signatures
    fun hapticListen() {
        vibratePattern(longArrayOf(0, 40), intArrayOf(0, 180))
    }

    fun hapticConfirm() {
        vibratePattern(longArrayOf(0, 30, 50, 30), intArrayOf(0, 200, 0, 200))
    }

    fun hapticFail() {
        vibratePattern(longArrayOf(0, 150), intArrayOf(0, 255))
    }

    fun hapticWarning() {
        vibratePattern(longArrayOf(0, 80, 40, 80, 40, 80), intArrayOf(0, 250, 0, 250, 0, 250))
    }

    private fun vibratePattern(timings: LongArray, amplitudes: IntArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(timings, -1)
            }
        } catch (e: Exception) {
            // Ignore if vibration fails
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
