package com.example.services

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.sqrt

data class FallAlertState(
    val isFallDetected: Boolean = false,
    val countdownSeconds: Int = 10,
    val gForceImpact: Float = 0f,
    val statusMessage: String = ""
)

class FallDetectionEngine(
    private val context: Context,
    private val onEmergencyTriggered: (message: String) -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val _alertState = MutableStateFlow(FallAlertState())
    val alertState: StateFlow<FallAlertState> = _alertState

    private var lastImpactTimestamp: Long = 0
    private var isMonitoring = false

    fun startMonitoring() {
        if (!isMonitoring && accelerometer != null) {
            sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
            isMonitoring = true
        }
    }

    fun stopMonitoring() {
        if (isMonitoring) {
            sensorManager?.unregisterListener(this)
            isMonitoring = false
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        // Calculate magnitude of acceleration
        val acceleration = sqrt((x * x + y * y + z * z).toDouble()).toFloat()

        // Impact threshold: standard gravity is ~9.81 m/s^2. High impact spike > 22.0 m/s^2 (~2.2G)
        if (acceleration > 22.0f && System.currentTimeMillis() - lastImpactTimestamp > 5000) {
            lastImpactTimestamp = System.currentTimeMillis()
            triggerFallWarning(acceleration)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    fun triggerFallWarning(gForce: Float = 24.5f) {
        _alertState.value = FallAlertState(
            isFallDetected = true,
            countdownSeconds = 10,
            gForceImpact = gForce,
            statusMessage = "ඇදවැටීමක් හඳුනාගන්නා ලදී! තත්පර 10 කින් හදිසි SMS එකක් යවනු ලැබේ. 'නවත්වන්න' පවසන්න හෝ තිරය ස්පර්ශ කරන්න."
        )
    }

    fun cancelFallAlert(): String {
        _alertState.value = FallAlertState(
            isFallDetected = false,
            countdownSeconds = 10,
            gForceImpact = 0f,
            statusMessage = "හදිසි ඇදවැටීම් අනතුරු ඇඟවීම අවලංගු කරන ලදී."
        )
        return "හදිසි අනතුරු ඇඟවීම සාර්ථකව අවලංගු විය."
    }

    fun dispatchEmergencySos(): String {
        val msg = "හදිසි අවස්ථාවයි! පරිශීලකයා හදිසි ඇදවැටීමකට ලක්ව ඇත. GPS පිහිටීම: කොළඹ 07."
        onEmergencyTriggered(msg)
        _alertState.value = _alertState.value.copy(
            isFallDetected = false,
            statusMessage = "හදිසි SOS කෙටි පණිවිඩය ප්‍රාථමික සම්බන්ධතාවයට යවන ලදී."
        )
        return msg
    }
}
