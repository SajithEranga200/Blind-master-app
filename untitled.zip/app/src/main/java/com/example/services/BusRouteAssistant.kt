package com.example.services

data class BusRouteInfo(
    val routeNumber: String,
    val origin: String,
    val destination: String,
    val nearestStop: String,
    val distanceMeters: Int,
    val estimatedArrivalMins: Int
)

class BusRouteAssistant {

    private val sampleRoutes = listOf(
        BusRouteInfo("138", "පිටකොටුව", "මහරගම", "මහරගම බස් නැවතුම", 120, 3),
        BusRouteInfo("120", "පිටකොටුව", "හොරණ", "තොටළඟ බස් නැවතුම", 250, 6),
        BusRouteInfo("177", "කොල්ලුපිටිය", "කඩුවෙල", "කඩුවෙල බස් නැවතුම", 400, 10),
        BusRouteInfo("100", "පිටකොටුව", "පානදූර", "ගල්කිස්ස බස් නැවතුම", 180, 4),
        BusRouteInfo("154", "කිරිබත්ගොඩ", "අංගොඩ", "කිරිබත්ගොඩ හන්දිය", 300, 7)
    )

    fun findNearestBusStopAndRoute(userQuery: String): String {
        val queryLower = userQuery.lowercase()

        val matchedRoute = sampleRoutes.find {
            queryLower.contains(it.routeNumber) ||
                    queryLower.contains(it.origin.lowercase()) ||
                    queryLower.contains(it.destination.lowercase())
        } ?: sampleRoutes[0]

        return "ලඟම බස් නැවතුම: ${matchedRoute.nearestStop} (මීටර් ${matchedRoute.distanceMeters} ක් දුරින්). " +
                "ඊළඟ බස් රථය: අංක ${matchedRoute.routeNumber} (${matchedRoute.origin} - ${matchedRoute.destination}) " +
                "තවත් මිනිත්තු ${matchedRoute.estimatedArrivalMins} කින් පැමිණේ. මඟපෙන්වීම: කෙළින්ම මීටර් 120ක් ඉදිරියට ඇවිදින්න."
    }

    fun getActiveNavigationStatus(): String {
        return "ගමනාගමන සහායක සක්‍රියයි. මීටර් 80 කින් වම්පස ඇති 138 බස් නැවතුම වෙත ළඟාවේ."
    }
}
