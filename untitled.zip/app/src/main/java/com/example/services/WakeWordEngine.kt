package com.example.services

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class WakeWordEngine(private val context: Context) {

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private var activeWakePhrase = "සහායක"
    private var sensitivityThreshold = "Medium" // Low, Medium, High

    fun configure(phrase: String, sensitivity: String) {
        this.activeWakePhrase = phrase
        this.sensitivityThreshold = sensitivity
    }

    fun startListening(onWakeDetected: (String) -> Unit) {
        _isListening.value = true
    }

    fun stopListening() {
        _isListening.value = false
    }

    fun getActiveWakePhrase(): String = activeWakePhrase
}
