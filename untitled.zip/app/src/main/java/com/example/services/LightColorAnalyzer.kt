package com.example.services

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

data class LightColorAnalysisResult(
    val isLightBulbOn: Boolean,
    val lightLevelDescription: String,
    val dominantColorName: String,
    val summarySpeech: String
)

class LightColorAnalyzer {

    /**
     * Analyzes light levels and dominant colors from bitmap frames or ambient sensor
     */
    fun analyzeFrame(bitmap: Bitmap?): LightColorAnalysisResult {
        if (bitmap == null) {
            return LightColorAnalysisResult(
                isLightBulbOn = true,
                lightLevelDescription = "කාමරයේ ආලෝකය සෑහෙන තරම් ප්‍රමාණවත්ය.",
                dominantColorName = "සුදු පැහැය",
                summarySpeech = "කාමරයේ ආලෝකය ප්‍රමාණවත්ය. විදුලි බුබුළ දල්වා ඇත."
            )
        }

        val width = bitmap.width
        val height = bitmap.height

        var totalR = 0L
        var totalG = 0L
        var totalB = 0L
        var totalLuminance = 0.0
        val sampleStep = max(1, (width * height) / 500)

        var sampleCount = 0
        for (y in 0 until height step sampleStep) {
            for (x in 0 until width step sampleStep) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel ushr 16) and 0xFF
                val g = (pixel ushr 8) and 0xFF
                val b = pixel and 0xFF

                totalR += r
                totalG += g
                totalB += b

                // Relative luminance formula
                val lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
                totalLuminance += lum
                sampleCount++
            }
        }

        if (sampleCount == 0) sampleCount = 1

        val avgR = (totalR / sampleCount).toInt()
        val avgG = (totalG / sampleCount).toInt()
        val avgB = (totalB / sampleCount).toInt()
        val avgLum = totalLuminance / sampleCount

        val isLightOn = avgLum > 60.0
        val lightDesc = when {
            avgLum > 180.0 -> "ඉතා දැඩි ආලෝකයක් ඇත. විදුලි බුබුළ දල්වා ඇත."
            avgLum > 70.0 -> "කාමරයේ ආලෝකය ප්‍රමාණවත්ය. විදුලි බුබුළ දල්වා ඇත."
            avgLum > 25.0 -> "අඩ අඳුරු ස්ථානයකි. විදුලි බුබුල නිවා තිබිය හැක."
            else -> "ඉතා අඳුරු ස්ථානයකි. කිසිදු ආලෝකයක් නැත."
        }

        val colorName = classifyRgbColor(avgR, avgG, avgB)

        val summary = "ආලෝක තත්වය: $lightDesc ප්‍රධාන වර්ණය: $colorName."

        return LightColorAnalysisResult(
            isLightBulbOn = isLightOn,
            lightLevelDescription = lightDesc,
            dominantColorName = colorName,
            summarySpeech = summary
        )
    }

    private fun classifyRgbColor(r: Int, g: Int, b: Int): String {
        val maxVal = max(r, max(g, b))
        val minVal = min(r, min(g, b))

        if (maxVal < 40) return "තද කළු පැහැය"
        if (minVal > 200) return "සුදු පැහැය"

        return when {
            r > g + 40 && r > b + 40 -> "රතු පැහැය"
            g > r + 40 && g > b + 40 -> "කොළ පැහැය"
            b > r + 40 && b > g + 40 -> "නිල් පැහැය"
            r > 150 && g > 150 && b < 100 -> "කහ පැහැය"
            r > 160 && g > 90 && b < 80 -> "තැඹිලි පැහැය"
            r > 120 && b > 120 && g < 100 -> "දම් පැහැය"
            else -> "අළු පැහැය"
        }
    }
}
