package com.example.services

import com.example.data.local.AssistiveRepository
import com.example.data.local.MedicineReminderEntity
import kotlinx.coroutines.flow.first

class MedicineReminderEngine(
    private val repository: AssistiveRepository
) {

    suspend fun getDailyMedicinesSummary(): String {
        val medicines = repository.allMedicines.first()
        if (medicines.isEmpty()) {
            return "ලියාපදිංචි කළ බෙහෙත් වර්ග කිසිවක් නැත. සැකසුම් මගින් නව බෙහෙත් එක් කළ හැක."
        }

        val untaken = medicines.filter { !it.isTakenToday }
        if (untaken.isEmpty()) {
            return "අද දිනයට නියමිත සියලුම බෙහෙත් ලබාගෙන ඇත."
        }

        val sb = java.lang.StringBuilder("අද දිනට ලබාගැනීමට ඇති බෙහෙත් පෙති:\n")
        untaken.forEachIndexed { idx, med ->
            sb.append("${idx + 1}. ${med.medicineName} (${med.dosage}) - වේලාව: ${med.timeOfDay}\n")
        }
        return sb.toString()
    }

    suspend fun addDefaultSampleMedicines() {
        val current = repository.allMedicines.first()
        if (current.isEmpty()) {
            repository.insertMedicine(
                MedicineReminderEntity(
                    medicineName = "පැරසිටමෝල් 500mg",
                    dosage = "පෙති 1 යි - කෑමට පසු",
                    timeOfDay = "උදේ 8:00 සහ රාත්‍රී 8:00",
                    isTakenToday = false
                )
            )
            repository.insertMedicine(
                MedicineReminderEntity(
                    medicineName = "Multivitamin B-Complex",
                    dosage = "පෙති 1 යි",
                    timeOfDay = "දවල් 1:00",
                    isTakenToday = false
                )
            )
        }
    }
}
