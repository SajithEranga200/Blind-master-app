package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = DeepVoid,
    secondary = NeonPulseGreen,
    onSecondary = DeepVoid,
    tertiary = ElectricViolet,
    onTertiary = TextWhite,
    background = DeepVoid,
    onBackground = TextWhite,
    surface = SurfaceDarkGlass,
    onSurface = TextWhite,
    surfaceVariant = SurfaceDarkGlass,
    onSurfaceVariant = TextMuted,
    error = AlertRed,
    onError = TextWhite
)

@Composable
fun AssistiveAITheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

