package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.*

data class SettingCategoryItem(
    val id: Int,
    val titleSi: String,
    val titleEn: String,
    val description: String,
    val icon: ImageVector,
    val accentColor: Color
)

val CATEGORIES = listOf(
    SettingCategoryItem(1, "ශ්‍රව්‍ය සැකසුම්", "Voice Settings", "කථන වේගය, Pitch සහ භාෂාව", Icons.Default.GraphicEq, CyberCyan),
    SettingCategoryItem(2, "අවදි පද සැකසුම්", "Wake Word", "ක්‍රියාකාරී අවදි පදය සහ සංවේදීතාව", Icons.Default.RecordVoiceOver, NeonPulseGreen),
    SettingCategoryItem(3, "මුහුණු දත්තගබඩාව", "Face Database", "ML Kit මුහුණු ලියාපදිංචිය (SQLite)", Icons.Default.Face, ElectricViolet),
    SettingCategoryItem(4, "හදිසි සම්බන්ධතා", "Emergency Contacts", "ප්‍රාථමික/දෙවන සම්බන්ධතා ලැයිස්තුව", Icons.Default.ContactPhone, AlertRed),
    SettingCategoryItem(5, "ආරක්ෂාව සහ Voice Auth", "Security & Voice", "Voice Enrollment (පද 5) සහ PIN", Icons.Default.Security, CyberCyan),
    SettingCategoryItem(6, "AI මනාපයන්", "AI Preferences", "පිළිතුරු කෙටිබව සහ Scene Sampling", Icons.Default.Psychology, NeonYellow),
    SettingCategoryItem(7, "Hardware Integration", "Hardware & Camera", "කැමරාව, USB OTG සහ Haptics", Icons.Default.Hardware, NeonPulseGreen),
    SettingCategoryItem(8, "ගමනාගමන මනාපයන්", "Navigation Prefs", "ඇවිදීම, බස් රථ සහ බාධා අනතුරු ඇඟවීම්", Icons.Default.Navigation, CyberCyan),
    SettingCategoryItem(9, "බෙහෙත් වට්ටෝරු", "Medicine Reminders", "දෛනික බෙහෙත් පෙති සහ වේලාවන්", Icons.Default.Medication, NeonYellow),
    SettingCategoryItem(10, "මුදල් පසුම්බිය", "Currency Wallet", "මුදල් නෝට්ටු එකතුව සහ ඉතිහාසය", Icons.Default.AccountBalanceWallet, NeonPulseGreen),
    SettingCategoryItem(11, "Owner Profile", "Owner Profile", "ඡායාරූපය සහ නම වෙනස් කිරීම", Icons.Default.AccountCircle, CyberCyan)
)

@Composable
fun SettingsDashboardScreen(
    currentLanguage: String = "Sinhala",
    onCategorySelected: (Int) -> Unit,
    onLockGateClick: () -> Unit
) {
    val isEnglish = currentLanguage.lowercase().contains("eng")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isEnglish) "Settings Dashboard" else "සැකසුම් පුවරුව",
                    color = TextWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isEnglish) "PIN Verified Mode" else "ආරක්ෂිත PIN මඟින් තහවුරුයි",
                    color = NeonPulseGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Lock / Sign out button
            IconButton(
                onClick = onLockGateClick,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(SurfaceDarkGlass)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock Gate",
                    tint = AlertRed
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Categories Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(CATEGORIES) { category ->
                val title = if (isEnglish) category.titleEn else category.titleSi
                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    borderColor = category.accentColor,
                    onClick = { onCategorySelected(category.id) }
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(category.accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = category.titleEn,
                            tint = category.accentColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = title,
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = category.description,
                        color = TextMuted,
                        fontSize = 11.sp,
                        maxLines = 2,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}
