package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class AppActiveState {
    IDLE,
    LISTENING,
    PROCESSING
}

@Composable
fun GlowOrb(
    state: AppActiveState,
    audioLevel: Float = 0.5f,
    onClick: () -> Unit = {},
    sizeDp: Dp = 220.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbTransition")

    // Breathing Scale
    val idleScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "IdleScale"
    )

    // Rotation angle
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state == AppActiveState.PROCESSING) 1200 else 6000,
                easing = LinearEasing
            )
        ),
        label = "Rotation"
    )

    // Expanding Pulse Alpha
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseAlpha"
    )

    Box(
        modifier = Modifier
            .size(sizeDp + 40.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        // Outer Neon Expanding Rings for Listening state
        if (state == AppActiveState.LISTENING) {
            val dynamicExpandScale = (1.0f + (audioLevel * 0.35f)).coerceIn(1.0f, 1.5f)
            Canvas(modifier = Modifier.size(sizeDp + 60.dp)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPulseGreen.copy(alpha = 0.4f * pulseAlpha),
                            CyberCyan.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    ),
                    radius = (size.minDimension / 2f) * dynamicExpandScale
                )
                drawCircle(
                    color = NeonPulseGreen.copy(alpha = 0.7f),
                    radius = (size.minDimension / 2.2f) * dynamicExpandScale,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }

        // Processing outer gradient ring
        if (state == AppActiveState.PROCESSING) {
            Canvas(
                modifier = Modifier
                    .size(sizeDp + 20.dp)
                    .rotate(rotationAngle)
            ) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            CyberCyan,
                            ElectricViolet,
                            NeonPulseGreen,
                            CyberCyan
                        )
                    ),
                    style = Stroke(width = 6.dp.toPx())
                )
            }
        }

        // Background Glow Ambient Blur
        Box(
            modifier = Modifier
                .size(sizeDp - 20.dp)
                .scale(if (state == AppActiveState.IDLE) idleScale else 1.0f)
                .blur(30.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = when (state) {
                            AppActiveState.IDLE -> listOf(CyberCyan.copy(alpha = 0.6f), ElectricViolet.copy(alpha = 0.3f), Color.Transparent)
                            AppActiveState.LISTENING -> listOf(NeonPulseGreen.copy(alpha = 0.8f), CyberCyan.copy(alpha = 0.4f), Color.Transparent)
                            AppActiveState.PROCESSING -> listOf(ElectricViolet.copy(alpha = 0.8f), CyberCyan.copy(alpha = 0.4f), Color.Transparent)
                        }
                    ),
                    shape = CircleShape
                )
        )

        // Core 3D Glassmorphic Orb
        Box(
            modifier = Modifier
                .size(sizeDp)
                .scale(if (state == AppActiveState.IDLE) idleScale else 1.0f)
                .rotate(if (state == AppActiveState.PROCESSING) rotationAngle else 0f)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = when (state) {
                            AppActiveState.IDLE -> listOf(CyberCyan, ElectricViolet, DeepVoid)
                            AppActiveState.LISTENING -> listOf(NeonPulseGreen, CyberCyan, DeepVoid)
                            AppActiveState.PROCESSING -> listOf(ElectricViolet, CyberCyan, NeonPulseGreen)
                        }
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // Inner Glass Shimmer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.35f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.5f)
                            )
                        )
                    )
            )

            // Status Label inside Orb
            val labelText = when (state) {
                AppActiveState.IDLE -> "සහායක\n(Idle)"
                AppActiveState.LISTENING -> "අහගෙන ඉන්නේ...\n(Listening)"
                AppActiveState.PROCESSING -> "පිළිතුරු සකස් වෙමින්...\n(Processing)"
            }

            Text(
                text = labelText,
                color = TextWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}
