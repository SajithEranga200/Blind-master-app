package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SurfaceDarkBorder
import com.example.ui.theme.SurfaceDarkGlass

@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderColor: Color = SurfaceDarkBorder,
    borderWidth: Dp = 1.dp,
    backgroundColor: Color = SurfaceDarkGlass,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val clickableModifier = if (onClick != null) {
        Modifier.clip(shape).clickable { onClick() }
    } else Modifier

    Box(
        modifier = modifier
            .clip(shape)
            .then(clickableModifier)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x2BFFFFFF),
                        Color(0x0A0A0E17)
                    )
                )
            )
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        backgroundColor.copy(alpha = 0.65f),
                        backgroundColor.copy(alpha = 0.35f)
                    )
                )
            )
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(
                    colors = listOf(
                        borderColor.copy(alpha = 0.8f),
                        borderColor.copy(alpha = 0.2f),
                        Color.White.copy(alpha = 0.1f)
                    )
                ),
                shape = shape
            )
            .padding(18.dp)
    ) {
        Column {
            content()
        }
    }
}

