package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.*

data class OptionItem(
    val id: String,
    val titleSin: String,
    val titleEng: String,
    val description: String,
    val icon: ImageVector,
    val color: Color,
    val categoryId: Int? = null,
    val voiceCommand: String? = null
)

val OPTION_ITEMS = listOf(
    OptionItem(
        id = "currency",
        titleSin = "මුදල් නෝට්ටු සහ පසුම්බිය",
        titleEng = "Currency & Wallet",
        description = "නෝට්ටු පරීක්ෂාව සහ වත්මන් මුදල් එකතුව",
        icon = Icons.Default.Payments,
        color = NeonYellow,
        categoryId = 10,
        voiceCommand = "මගේ මුදල් එකතුව සහ නෝට්ටු පරීක්ෂා කරන්න"
    ),
    OptionItem(
        id = "light_color",
        titleSin = "ආලෝකය සහ වර්ණ",
        titleEng = "Light & Color Detector",
        description = "කාමරයේ එළිය සහ ඇඳුම්වල වර්ණ හඳුනාගැනීම",
        icon = Icons.Default.WbSunny,
        color = CyberCyan,
        voiceCommand = "කාමරයේ ආලෝකය සහ වර්ණ විස්තර කරන්න"
    ),
    OptionItem(
        id = "bus_routes",
        titleSin = "බස් නැවතුම් සහ ගමනාගමනය",
        titleEng = "Bus Routes & Navigation",
        description = "ළඟම බස් නැවතුම සහ ගමනාන්ත මාර්ග",
        icon = Icons.Default.DirectionsBus,
        color = NeonPulseGreen,
        categoryId = 8,
        voiceCommand = "ලඟම බස් නැවතුම සහ බස් රථය"
    ),
    OptionItem(
        id = "medicines",
        titleSin = "බෙහෙත් වට්ටෝරු සහ වේලාවන්",
        titleEng = "Medicine Reminders",
        description = "දෛනික බෙහෙත් පෙති මතක් කිරීම්",
        icon = Icons.Default.Medication,
        color = ElectricViolet,
        categoryId = 9,
        voiceCommand = "අද මගේ බෙහෙත් වෙලාවන් මොනවාද?"
    ),
    OptionItem(
        id = "ocr_reader",
        titleSin = "ලිපි ලේඛන කියවීම (OCR)",
        titleEng = "Document & Text Reader",
        description = "පොත්, ලිපි සහ මුද්‍රිත පත්‍රිකා කියවීම",
        icon = Icons.Default.DocumentScanner,
        color = CyberCyan,
        voiceCommand = "මම අල්ලාගෙන සිටින ලේඛනය හෝ මුදල් නෝට්ටුව කියවන්න."
    ),
    OptionItem(
        id = "obstacles",
        titleSin = "බාධා අනතුරු ඇඟවීම",
        titleEng = "Obstacle Detection",
        description = "ඉදිරියෙන් ඇති බාධා හඳුනා ගැනීම",
        icon = Icons.Default.WarningAmber,
        color = AlertRed,
        voiceCommand = "මගේ ඉදිරියෙන් ඇති බාධා මොනවාද?"
    ),
    OptionItem(
        id = "assistant_voice",
        titleSin = "සහායක සහ වාචික සැකසුම්",
        titleEng = "Assistant & Voice Customizer",
        description = "සහායක නම (Wake Word) සහ කතා කරන වේගය",
        icon = Icons.Default.RecordVoiceOver,
        color = NeonPulseGreen,
        categoryId = 2
    ),
    OptionItem(
        id = "emergency",
        titleSin = "හදිසි ඇමතුම් (SOS Contacts)",
        titleEng = "Emergency & Contacts",
        description = "හදිසි අවස්ථාවකදී දැනුම් දෙන අංක",
        icon = Icons.Default.ContactPhone,
        color = AlertRed,
        categoryId = 4
    )
)

@Composable
fun OptionsDashboardScreen(
    currentLanguage: String = "Sinhala",
    onBackClick: () -> Unit,
    onOptionSelected: (OptionItem) -> Unit,
    onNavigateToCategory: (Int) -> Unit
) {
    val isEnglish = currentLanguage.lowercase().contains("eng")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(SurfaceDarkGlass)
                        .border(1.dp, SurfaceDarkBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhite
                    )
                }

                Column {
                    Text(
                        text = if (isEnglish) "Options & Features" else "විශේෂාංග සහ විකල්ප",
                        color = TextWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isEnglish) "Quick Action Dashboard" else "ක්‍ෂණික මඟපෙන්වීම් සහ විකල්ප",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Options Grid Layout
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(OPTION_ITEMS) { option ->
                val title = if (isEnglish) option.titleEng else option.titleSin
                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clickable {
                            if (option.categoryId != null) {
                                onNavigateToCategory(option.categoryId)
                            } else {
                                onOptionSelected(option)
                            }
                        },
                    borderColor = option.color,
                    cornerRadius = 20.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SurfaceDarkGlass)
                                .border(1.dp, option.color, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = option.icon,
                                contentDescription = option.titleEng,
                                tint = option.color,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Column {
                            Text(
                                text = title,
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = option.description,
                                color = TextMuted,
                                fontSize = 10.sp,
                                lineHeight = 13.sp,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Return Home Glass Button
        Button(
            onClick = onBackClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(26.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDarkGlass),
            border = ButtonDefaults.outlinedButtonBorder.copy(
                brush = Brush.linearGradient(listOf(CyberCyan, ElectricViolet))
            )
        ) {
            Icon(
                imageVector = Icons.Default.Home,
                contentDescription = "Home",
                tint = CyberCyan
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isEnglish) "Return Home" else "මුඛ්‍ය තිරයට ආපසු",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}
