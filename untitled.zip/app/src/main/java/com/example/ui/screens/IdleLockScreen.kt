package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.services.AccessRole
import com.example.services.FallAlertState
import com.example.ui.components.AppActiveState
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowOrb
import com.example.ui.theme.*

@Composable
fun IdleLockScreen(
    activeState: AppActiveState,
    lastAiResponse: String,
    accessRole: AccessRole,
    wakeWord: String,
    walletTotal: Double = 0.0,
    fallAlert: FallAlertState = FallAlertState(),
    ownerName: String = "John Doe",
    ownerPhotoAvatar: Int = 1,
    currentLanguage: String = "Sinhala",
    onCancelFallAlert: () -> Unit = {},
    onVoiceTriggerClick: (prompt: String) -> Unit,
    onCameraScanClick: () -> Unit,
    onDocumentScanClick: () -> Unit,
    onSettingsGateClick: () -> Unit,
    onOptionsClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var simulatedVoiceInputText by remember { mutableStateOf("") }
    var isSimulatingVoiceDialog by remember { mutableStateOf(false) }
    var showOptionsSheet by remember { mutableStateOf(false) }

    val isEnglish = currentLanguage.lowercase().contains("eng")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepVoid)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Owner Profile Pill (Clickable to open settings)
                Row(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(SurfaceDarkGlass)
                        .border(1.dp, CyberCyan, CircleShape)
                        .clickable { onSettingsGateClick() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(CyberCyan.copy(alpha = 0.2f))
                            .border(1.dp, NeonPulseGreen, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val avatarIcon = when (ownerPhotoAvatar) {
                            2 -> Icons.Default.Face
                            3 -> Icons.Default.AccountCircle
                            4 -> Icons.Default.Psychology
                            else -> Icons.Default.Person
                        }
                        Icon(
                            imageVector = avatarIcon,
                            contentDescription = "Owner Avatar",
                            tint = NeonPulseGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Text(
                        text = "Owner: $ownerName",
                        color = TextWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Wallet Total Balance Badge
                Row(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(SurfaceDarkGlass)
                        .border(1.dp, NeonYellow, CircleShape)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = "Wallet",
                        tint = NeonYellow,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "රු. ${walletTotal.toInt()}",
                        color = NeonYellow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Fall Detection Siren Banner
            if (fallAlert.isFallDetected) {
                Spacer(modifier = Modifier.height(8.dp))
                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = AlertRed,
                    cornerRadius = 20.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("⚠️ ඇදවැටීමක් හඳුනාගන්නා ලදී!", color = AlertRed, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(fallAlert.statusMessage, color = TextWhite, fontSize = 12.sp)
                        }
                        Button(
                            onClick = onCancelFallAlert,
                            colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                        ) {
                            Text("නවත්වන්න (Cancel SOS)", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Prominent AI Assistant Response Card (Positioned higher up & enlarged)
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberCyan,
                cornerRadius = 22.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = "Voice Output",
                        tint = NeonPulseGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (isEnglish) "AI Assistant Statement:" else "AI සහායක ප්‍රකාශය:",
                        color = NeonPulseGreen,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = lastAiResponse,
                    color = TextWhite,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 24.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Compact Camera Preview Widget
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clickable { onCameraScanClick() },
                borderColor = CyberCyan,
                cornerRadius = 24.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF0B0F19), Color(0xFF020617)))),
                    contentAlignment = Alignment.Center
                ) {
                    // Viewfinder corner marks
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("┌", color = CyberCyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("┐", color = CyberCyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("└", color = CyberCyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("┘", color = CyberCyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(SurfaceDarkGlass)
                                .border(1.dp, NeonPulseGreen, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Camera Viewfinder Widget",
                                tint = NeonPulseGreen,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Text(
                            text = if (isEnglish) "AI Camera Active" else "AI කැමරා සංවේදකය සක්‍රියයි",
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = if (isEnglish) "Realtime Scene Recognition" else "තත්‍ය කාලීන දර්ශන පරික්ෂාව",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(SurfaceDarkGlass)
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(NeonPulseGreen)
                            )
                            Text(
                                text = if (isEnglish) "Tap to Scan Scene" else "ස්පර්ශ කරන්න / Scene Scan",
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Central Interactive Glow Orb
            GlowOrb(
                state = activeState,
                audioLevel = 0.7f,
                onClick = {
                    isSimulatingVoiceDialog = true
                },
                sizeDp = 130.dp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Navigation & Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bottom Left: Settings Icon Button (Icon ONLY, no text label)
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(SurfaceDarkGlass)
                        .border(1.dp, CyberCyan, CircleShape)
                        .clickable { onSettingsGateClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = CyberCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Bottom Center: Main Assistant ("සහායක") Voice Trigger Button (Scaled down, NO mic icon)
                Button(
                    onClick = { isSimulatingVoiceDialog = true },
                    modifier = Modifier
                        .height(48.dp)
                        .padding(horizontal = 12.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                ) {
                    Text(
                        text = "සහායක",
                        color = DeepVoid,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                // Bottom Right: Options Icon Button (Icon ONLY, no text label)
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(SurfaceDarkGlass)
                        .border(1.dp, ElectricViolet, CircleShape)
                        .clickable { onOptionsClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Options",
                        tint = TextWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Options Bottom Sheet Modal
        if (showOptionsSheet) {
            AlertDialog(
                onDismissRequest = { showOptionsSheet = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("විශේෂාංග සහ විකල්ප (Options)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        IconButton(onClick = { showOptionsSheet = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Option 1: Currency & Wallet
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onVoiceTriggerClick("මගේ මුදල් එකතුව සහ නෝට්ටු පරීක්ෂා කරන්න")
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = NeonYellow)
                            Spacer(Modifier.width(8.dp))
                            Text("මුදල් නෝට්ටු සහ පසුම්බිය (Currency)", color = TextWhite)
                        }

                        // Option 2: Light & Color Detector
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onVoiceTriggerClick("කාමරයේ ආලෝකය සහ වර්ණ විස්තර කරන්න")
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.WbSunny, contentDescription = null, tint = CyberCyan)
                            Spacer(Modifier.width(8.dp))
                            Text("ආලෝකය සහ වර්ණ පරීක්ෂාව (Light/Color)", color = TextWhite)
                        }

                        // Option 3: Bus Route
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onVoiceTriggerClick("ලඟම බස් නැවතුම සහ බස් රථය")
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.DirectionsBus, contentDescription = null, tint = NeonPulseGreen)
                            Spacer(Modifier.width(8.dp))
                            Text("බස් නැවතුම් සහ ගමනාගමනය (Bus Route)", color = TextWhite)
                        }

                        // Option 4: Medicine Reminders
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onVoiceTriggerClick("අද මගේ බෙහෙත් වෙලාවන් මොනවාද?")
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Medication, contentDescription = null, tint = NeonYellow)
                            Spacer(Modifier.width(8.dp))
                            Text("බෙහෙත් වට්ටෝරු සහ වේලාවන් (Medicines)", color = TextWhite)
                        }

                        // Option 5: Document & Text Scanner
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onDocumentScanClick()
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.DocumentScanner, contentDescription = null, tint = ElectricViolet)
                            Spacer(Modifier.width(8.dp))
                            Text("පොත / ලිපි ලේඛන කියවීම (OCR Reader)", color = TextWhite)
                        }

                        // Option 6: Obstacle Finder
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onVoiceTriggerClick("මගේ ඉදිරියෙන් ඇති බාධා මොනවාද?")
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = AlertRed)
                            Spacer(Modifier.width(8.dp))
                            Text("බාධා අනතුරු ඇඟවීම (Obstacle Scan)", color = TextWhite)
                        }
                    }
                },
                confirmButton = {},
                containerColor = DeepVoid,
                shape = RoundedCornerShape(24.dp)
            )
        }

        // Voice Command Input Dialog Simulation
        if (isSimulatingVoiceDialog) {
            AlertDialog(
                onDismissRequest = { isSimulatingVoiceDialog = false },
                title = {
                    Text("වාචික විධානයක් ලබා දෙන්න (Voice Command)", color = TextWhite, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column {
                        Text("ඔබට විමසීමට අවශ්‍ය දෙය ඇතුළත් කරන්න හෝ පවසන්න:", color = TextMuted)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = simulatedVoiceInputText,
                            onValueChange = { simulatedVoiceInputText = it },
                            placeholder = { Text("උදා: මගේ ඉදිරියේ තියෙන්නේ මොනවාද?", color = TextMuted) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = SurfaceDarkBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val textToProcess = if (simulatedVoiceInputText.isBlank()) "මගේ වටපිටාව විස්තර කරන්න" else simulatedVoiceInputText
                            isSimulatingVoiceDialog = false
                            simulatedVoiceInputText = ""
                            onVoiceTriggerClick(textToProcess)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                    ) {
                        Text("යවන්න (Send)", color = DeepVoid, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { isSimulatingVoiceDialog = false }) {
                        Text("අවලංගු කරන්න", color = TextMuted)
                    }
                },
                containerColor = DeepVoid,
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}
