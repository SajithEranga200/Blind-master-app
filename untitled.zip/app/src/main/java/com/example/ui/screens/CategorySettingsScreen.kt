package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AiResponseCacheEntity
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.FaceEntity
import com.example.data.local.MedicineReminderEntity
import com.example.data.local.VoiceSampleEntity
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategorySettingsScreen(
    categoryId: Int,
    uiState: UiState,
    faces: List<FaceEntity>,
    contacts: List<EmergencyContactEntity>,
    voiceSamples: List<VoiceSampleEntity>,
    medicines: List<MedicineReminderEntity> = emptyList(),
    cachedAiResponses: List<AiResponseCacheEntity> = emptyList(),
    onBackClick: () -> Unit,
    onUpdateVoiceSettings: (speed: Float, pitch: Float, language: String) -> Unit,
    onUpdateWakeWordSettings: (phrase: String, sensitivity: String) -> Unit,
    onUpdateAiPreferences: (conciseness: String, samplingRate: Int) -> Unit,
    onUpdateHardwarePreferences: (cameraSource: String, audioOutput: String) -> Unit,
    onUpdateNavigationPreferences: (transportMode: String, obstacleAvoidance: Boolean) -> Unit,
    onUpdateSecurityPin: (oldPin: String, newPin: String) -> Boolean,
    onEnrollVoiceSample: (index: Int, text: String) -> Unit,
    onAddEmergencyContact: (name: String, phone: String, relationship: String, isPrimary: Boolean) -> Unit,
    onDeleteEmergencyContact: (contact: EmergencyContactEntity) -> Unit,
    onRegisterFace: (name: String) -> Unit,
    onDeleteFace: (face: FaceEntity) -> Unit,
    onAddMedicine: (name: String, dosage: String, timeOfDay: String) -> Unit = { _, _, _ -> },
    onDeleteMedicine: (medicine: MedicineReminderEntity) -> Unit = {},
    onClearWallet: () -> Unit = {},
    onUpdateOwnerProfile: (name: String, avatarId: Int) -> Unit = { _, _ -> },
    onClearAiCache: () -> Unit = {}
) {
    val category = CATEGORIES.find { it.id == categoryId } ?: CATEGORIES[0]

    // Dialog state for sub-actions
    var showAddContactDialog by remember { mutableStateOf(false) }
    var showRegisterFaceDialog by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAddMedicineDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepVoid)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(SurfaceDarkGlass)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = CyberCyan
                    )
                }

                Column {
                    Text(
                        text = category.titleSi,
                        color = TextWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = category.titleEn,
                        color = category.accentColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (categoryId) {
                    // Category 1: Voice Settings
                    1 -> {
                        item {
                            GlassmorphicCard {
                                Text("කථන වේගය (Voice Speed): ${"%.1f".format(uiState.voiceSpeed)}x", color = TextWhite, fontWeight = FontWeight.Bold)
                                Slider(
                                    value = uiState.voiceSpeed,
                                    onValueChange = { onUpdateVoiceSettings(it, uiState.voicePitch, uiState.currentLanguage) },
                                    valueRange = 0.5f..2.0f,
                                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text("කථන ස්වරය (Pitch): ${"%.1f".format(uiState.voicePitch)}", color = TextWhite, fontWeight = FontWeight.Bold)
                                Slider(
                                    value = uiState.voicePitch,
                                    onValueChange = { onUpdateVoiceSettings(uiState.voiceSpeed, it, uiState.currentLanguage) },
                                    valueRange = 0.5f..2.0f,
                                    colors = SliderDefaults.colors(thumbColor = NeonPulseGreen, activeTrackColor = NeonPulseGreen)
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text("ප්‍රාථමික භාෂාව (Language):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Sinhala", "English", "Tamil").forEach { lang ->
                                        FilterChip(
                                            selected = uiState.currentLanguage == lang,
                                            onClick = { onUpdateVoiceSettings(uiState.voiceSpeed, uiState.voicePitch, lang) },
                                            label = { Text(lang) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = CyberCyan,
                                                selectedLabelColor = DeepVoid
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Category 2: Wake Word Settings
                    2 -> {
                        item {
                            GlassmorphicCard {
                                Text("ක්‍රියාකාරී අවදි පදය (Wake Word):", color = TextWhite, fontWeight = FontWeight.Bold)
                                var tempWake by remember { mutableStateOf(uiState.wakeWord) }
                                OutlinedTextField(
                                    value = tempWake,
                                    onValueChange = {
                                        tempWake = it
                                        onUpdateWakeWordSettings(it, uiState.wakeSensitivity)
                                    },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberCyan)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Text("සංවේදීතා මට්ටම (Sensitivity):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Low", "Medium", "High").forEach { sens ->
                                        FilterChip(
                                            selected = uiState.wakeSensitivity == sens,
                                            onClick = { onUpdateWakeWordSettings(uiState.wakeWord, sens) },
                                            label = { Text(sens) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = NeonPulseGreen,
                                                selectedLabelColor = DeepVoid
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Category 3: Face Database (Local SQLite Room)
                    3 -> {
                        item {
                            Button(
                                onClick = { showRegisterFaceDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add Face")
                                Spacer(Modifier.width(8.dp))
                                Text("නව මුහුණක් ලියාපදිංචි කරන්න (Register Face)", fontWeight = FontWeight.Bold)
                            }
                        }

                        items(faces) { face ->
                            GlassmorphicCard(borderColor = ElectricViolet) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(face.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text("ලියාපදිංචි අගය: ${face.confidenceThreshold}", color = TextMuted, fontSize = 12.sp)
                                    }
                                    IconButton(onClick = { onDeleteFace(face) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AlertRed)
                                    }
                                }
                            }
                        }
                    }

                    // Category 4: Emergency Contacts & Backup
                    4 -> {
                        item {
                            Text(
                                text = "සටහන: SOS ස්වයංක්‍රීය ඇමතුම් මෙහි ඇතුළත් නොවන අතර හදිසි අවස්ථාවකදී භාවිතයට පමනක් පවතී.",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { showAddContactDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "Add Contact")
                                Spacer(Modifier.width(8.dp))
                                Text("හදිසි සම්බන්ධතාවයක් එක් කරන්න", fontWeight = FontWeight.Bold)
                            }
                        }

                        items(contacts) { contact ->
                            GlassmorphicCard(borderColor = AlertRed) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("${contact.name} (${contact.relationship})", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text("දුරකථන: ${contact.phone}", color = TextMuted, fontSize = 13.sp)
                                    }
                                    IconButton(onClick = { onDeleteEmergencyContact(contact) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AlertRed)
                                    }
                                }
                            }
                        }
                    }

                    // Category 5: Security & Voice Auth
                    5 -> {
                        item {
                            GlassmorphicCard(borderColor = CyberCyan) {
                                Text("Voice Enrollment (පද 5 ලියාපදිංචිය):", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("අයිතිකරු තහවුරු කිරීමට පද 5ක් පවසන්න:", color = TextMuted, fontSize = 12.sp)

                                Spacer(Modifier.height(12.dp))

                                voiceSamples.forEach { sample ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${sample.phraseIndex + 1}. \"${sample.phraseText}\"", color = TextWhite)
                                        Button(
                                            onClick = { onEnrollVoiceSample(sample.phraseIndex, sample.phraseText) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (sample.isEnrolled) NeonPulseGreen else CyberCyan
                                            )
                                        ) {
                                            Text(if (sample.isEnrolled) "ලියාපදිංචි වී ඇත" else "පටිගත කරන්න", color = DeepVoid, fontSize = 11.sp)
                                        }
                                    }
                                }

                                Spacer(Modifier.height(16.dp))

                                Button(
                                    onClick = { showChangePinDialog = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceDarkGlass)
                                ) {
                                    Icon(Icons.Default.LockReset, contentDescription = "Reset PIN", tint = CyberCyan)
                                    Spacer(Modifier.width(8.dp))
                                    Text("PIN අංකය වෙනස් කරන්න (Change PIN)", color = TextWhite)
                                }
                            }
                        }
                    }

                    // Category 6: AI Preferences & Offline Room Cache
                    6 -> {
                        item {
                            GlassmorphicCard(borderColor = NeonYellow) {
                                Text("පිළිතුරු විස්තර මට්ටම (Conciseness):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Short", "Detailed").forEach { mode ->
                                        FilterChip(
                                            selected = uiState.responseConciseness == mode,
                                            onClick = { onUpdateAiPreferences(mode, uiState.sceneSamplingRate) },
                                            label = { Text(mode) },
                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonYellow, selectedLabelColor = DeepVoid)
                                        )
                                    }
                                }

                                Spacer(Modifier.height(16.dp))

                                Text("Real-time Scene Sampling Frequency:", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(1, 3, 5).forEach { sec ->
                                        FilterChip(
                                            selected = uiState.sceneSamplingRate == sec,
                                            onClick = { onUpdateAiPreferences(uiState.responseConciseness, sec) },
                                            label = { Text("${sec}s") },
                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CyberCyan, selectedLabelColor = DeepVoid)
                                        )
                                    }
                                }

                                Spacer(Modifier.height(20.dp))

                                Text("Room Database Offline AI Cache:", color = TextWhite, fontWeight = FontWeight.Bold)
                                Text("සුරකින ලද AI පිළිතුරු ගණන: ${cachedAiResponses.size}", color = TextMuted, fontSize = 13.sp)

                                Spacer(Modifier.height(12.dp))

                                Button(
                                    onClick = onClearAiCache,
                                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Clear Cache")
                                    Spacer(Modifier.width(8.dp))
                                    Text("AI Cache දත්ත මකාදමන්න", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Category 7: Hardware Integration
                    7 -> {
                        item {
                            GlassmorphicCard(borderColor = NeonPulseGreen) {
                                Text("කැමරා ආදානය (Camera Source):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Internal", "External USB OTG").forEach { source ->
                                        FilterChip(
                                            selected = uiState.cameraSource == source,
                                            onClick = { onUpdateHardwarePreferences(source, uiState.audioOutputChannel) },
                                            label = { Text(source) },
                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonPulseGreen, selectedLabelColor = DeepVoid)
                                        )
                                    }
                                }

                                Spacer(Modifier.height(16.dp))

                                Text("ශ්‍රව්‍ය නිමැවුම (Audio Output):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Speaker", "Bluetooth", "Wired").forEach { channel ->
                                        FilterChip(
                                            selected = uiState.audioOutputChannel == channel,
                                            onClick = { onUpdateHardwarePreferences(uiState.cameraSource, channel) },
                                            label = { Text(channel) },
                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CyberCyan, selectedLabelColor = DeepVoid)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Category 8: Navigation Preferences
                    8 -> {
                        item {
                            GlassmorphicCard(borderColor = CyberCyan) {
                                Text("ගමනාගමන මාදිලිය (Transport Mode):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Walking", "Bus", "Car").forEach { mode ->
                                        FilterChip(
                                            selected = uiState.transportMode == mode,
                                            onClick = { onUpdateNavigationPreferences(mode, uiState.obstacleAvoidance) },
                                            label = { Text(mode) },
                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CyberCyan, selectedLabelColor = DeepVoid)
                                        )
                                    }
                                }

                                Spacer(Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("බාධා අනතුරු ඇඟවීම් (Obstacle Avoidance):", color = TextWhite, fontWeight = FontWeight.Bold)
                                    Switch(
                                        checked = uiState.obstacleAvoidance,
                                        onCheckedChange = { onUpdateNavigationPreferences(uiState.transportMode, it) },
                                        colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = SurfaceDarkGlass)
                                    )
                                }
                            }
                        }
                    }

                    // Category 9: Medicine Reminders
                    9 -> {
                        item {
                            Button(
                                onClick = { showAddMedicineDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = NeonYellow)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add Medicine", tint = DeepVoid)
                                Spacer(Modifier.width(8.dp))
                                Text("නව බෙහෙත් වට්ටෝරුවක් එක් කරන්න", color = DeepVoid, fontWeight = FontWeight.Bold)
                            }
                        }

                        items(medicines) { med ->
                            GlassmorphicCard(borderColor = NeonYellow) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(med.medicineName, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text("මාත්‍රාව: ${med.dosage} | වේලාව: ${med.timeOfDay}", color = TextMuted, fontSize = 12.sp)
                                    }
                                    IconButton(onClick = { onDeleteMedicine(med) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AlertRed)
                                    }
                                }
                            }
                        }
                    }

                    // Category 10: Currency Wallet
                    10 -> {
                        item {
                            GlassmorphicCard(borderColor = NeonPulseGreen) {
                                Text("වත්මන් පසුම්බි එකතුව (Wallet Balance):", color = TextWhite, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("LKR ${"%.2f".format(uiState.walletTotalAmount)}", color = NeonPulseGreen, fontSize = 28.sp, fontWeight = FontWeight.Bold)

                                Spacer(Modifier.height(16.dp))

                                Button(
                                    onClick = onClearWallet,
                                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Wallet")
                                    Spacer(Modifier.width(8.dp))
                                    Text("පසුම්බිය ශූන්‍ය කරන්න (Reset Balance)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Category 11: Owner Profile Photo & Name Settings
                    11 -> {
                        item {
                            var ownerNameInput by remember { mutableStateOf(uiState.ownerName) }
                            var selectedAvatarId by remember { mutableStateOf(uiState.ownerPhotoAvatar) }

                            GlassmorphicCard(borderColor = CyberCyan) {
                                Text(
                                    text = "Owner Profile Settings",
                                    color = TextWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = "Owner Avatar Photo Select:",
                                    color = TextMuted,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    listOf(
                                        1 to Icons.Default.Person,
                                        2 to Icons.Default.Face,
                                        3 to Icons.Default.AccountCircle,
                                        4 to Icons.Default.Psychology
                                    ).forEach { (id, icon) ->
                                        val isSelected = selectedAvatarId == id
                                        Box(
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(CircleShape)
                                                .background(if (isSelected) SurfaceDarkGlass else Color.Transparent)
                                                .border(
                                                    width = if (isSelected) 3.dp else 1.dp,
                                                    color = if (isSelected) NeonPulseGreen else SurfaceDarkBorder,
                                                    shape = CircleShape
                                                )
                                                .clickable { selectedAvatarId = id },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = icon,
                                                contentDescription = "Avatar $id",
                                                tint = if (isSelected) NeonPulseGreen else TextMuted,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                OutlinedTextField(
                                    value = ownerNameInput,
                                    onValueChange = { ownerNameInput = it },
                                    label = { Text("Owner Name", color = TextMuted) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = TextWhite,
                                        unfocusedTextColor = TextWhite,
                                        focusedBorderColor = CyberCyan,
                                        unfocusedBorderColor = SurfaceDarkBorder
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        onUpdateOwnerProfile(ownerNameInput, selectedAvatarId)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = "Save", tint = DeepVoid)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Save Owner Profile", color = DeepVoid, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sub-dialogs
        if (showAddMedicineDialog) {
            var medNameText by remember { mutableStateOf("") }
            var dosageText by remember { mutableStateOf("") }
            var timeOfDayText by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddMedicineDialog = false },
                title = { Text("නව බෙහෙත් පෙත්තක් එක් කරන්න", color = TextWhite) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = medNameText, onValueChange = { medNameText = it }, label = { Text("බෙහෙතේ නම") })
                        OutlinedTextField(value = dosageText, onValueChange = { dosageText = it }, label = { Text("මාත්‍රාව (උදා: පෙති 1යි)") })
                        OutlinedTextField(value = timeOfDayText, onValueChange = { timeOfDayText = it }, label = { Text("වේලාව (උදා: උදේ 8.00)") })
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (medNameText.isNotBlank()) {
                            onAddMedicine(medNameText, dosageText, timeOfDayText)
                            showAddMedicineDialog = false
                        }
                    }) { Text("සුරකින්න") }
                },
                dismissButton = { TextButton(onClick = { showAddMedicineDialog = false }) { Text("අවලංගු කරන්න") } },
                containerColor = DeepVoid
            )
        }
        if (showAddContactDialog) {
            var nameText by remember { mutableStateOf("") }
            var phoneText by remember { mutableStateOf("") }
            var relationText by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddContactDialog = false },
                title = { Text("හදිසි සම්බන්ධතාවයක් එක් කරන්න", color = TextWhite) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = nameText, onValueChange = { nameText = it }, label = { Text("නම (Name)") })
                        OutlinedTextField(value = phoneText, onValueChange = { phoneText = it }, label = { Text("දුරකථන අංකය") })
                        OutlinedTextField(value = relationText, onValueChange = { relationText = it }, label = { Text("සම්බන්ධතාවය") })
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (nameText.isNotBlank()) {
                            onAddEmergencyContact(nameText, phoneText, relationText, true)
                            showAddContactDialog = false
                        }
                    }) { Text("සුරකින්න") }
                },
                dismissButton = { TextButton(onClick = { showAddContactDialog = false }) { Text("අවලංගු කරන්න") } },
                containerColor = DeepVoid
            )
        }

        if (showRegisterFaceDialog) {
            var faceNameText by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showRegisterFaceDialog = false },
                title = { Text("නව මුහුණක් ලියාපදිංචිය", color = TextWhite) },
                text = {
                    Column {
                        Text("කැමරාව ඉදිරියේ සිට පුද්ගල නම ඇතුළත් කරන්න:", color = TextMuted)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = faceNameText, onValueChange = { faceNameText = it }, label = { Text("පුද්ගලයාගේ නම") })
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (faceNameText.isNotBlank()) {
                            onRegisterFace(faceNameText)
                            showRegisterFaceDialog = false
                        }
                    }) { Text("ලියාපදිංචි කරන්න") }
                },
                dismissButton = { TextButton(onClick = { showRegisterFaceDialog = false }) { Text("අවලංගු කරන්න") } },
                containerColor = DeepVoid
            )
        }

        if (showChangePinDialog) {
            var oldPin by remember { mutableStateOf("") }
            var newPin by remember { mutableStateOf("") }
            var statusMsg by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showChangePinDialog = false },
                title = { Text("PIN අංකය වෙනස් කිරීම", color = TextWhite) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = oldPin, onValueChange = { oldPin = it }, label = { Text("වත්මන් PIN අංකය") })
                        OutlinedTextField(value = newPin, onValueChange = { newPin = it }, label = { Text("නව PIN අංකය (අංක 4ක්)") })
                        if (statusMsg.isNotEmpty()) {
                            Text(statusMsg, color = AlertRed, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (onUpdateSecurityPin(oldPin, newPin)) {
                            showChangePinDialog = false
                        } else {
                            statusMsg = "වැරදි වත්මන් PIN අංකයකි!"
                        }
                    }) { Text("තහවුරු කරන්න") }
                },
                dismissButton = { TextButton(onClick = { showChangePinDialog = false }) { Text("අවලංගු කරන්න") } },
                containerColor = DeepVoid
            )
        }
    }
}
