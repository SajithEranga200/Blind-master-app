package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00F5FF)
val NeonPulseGreen = Color(0xFF00FF66)
val DeepVoid = Color(0xFF0A0E17)
val SurfaceDarkGlass = Color(0x26162032)
val SurfaceDarkBorder = Color(0x4000F5FF)
val ElectricViolet = Color(0xFFA855F7)
val AlertRed = Color(0xFFFF3366)
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF94A3B8)
val NeonYellow = Color(0xFFFFD600)

