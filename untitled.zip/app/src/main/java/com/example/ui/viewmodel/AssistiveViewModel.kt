package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.ApiRouterService
import com.example.data.ai.GeminiAiService
import com.example.data.local.AiResponseCacheEntity
import com.example.data.local.AppDatabase
import com.example.data.local.AssistiveRepository
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.FaceEntity
import com.example.data.local.MedicineReminderEntity
import com.example.data.local.VoiceSampleEntity
import com.example.data.security.SecurityVaultService
import com.example.services.AccessRole
import com.example.services.BusRouteAssistant
import com.example.services.CurrencyCounterEngine
import com.example.services.FallAlertState
import com.example.services.FallDetectionEngine
import com.example.services.LightColorAnalyzer
import com.example.services.MedicineReminderEngine
import com.example.services.TtsSpeechManager
import com.example.services.VoiceAuthManager
import com.example.services.WakeWordEngine
import com.example.ui.components.AppActiveState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiState(
    val activeState: AppActiveState = AppActiveState.IDLE,
    val lastAiResponse: String = "ආයුබෝවන්! මම ඔබේ AI සහායකයා වේ. 'සහායක' කියා පවසන්න.",
    val isPinAuthorized: Boolean = false,
    val currentLanguage: String = "Sinhala",
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val wakeWord: String = "සහායක",
    val wakeSensitivity: String = "Medium",
    val accessRole: AccessRole = AccessRole.Owner,
    val selectedCategory: Int = 1,
    val sceneSamplingRate: Int = 3,
    val responseConciseness: String = "Short",
    val cameraSource: String = "Internal",
    val audioOutputChannel: String = "Speaker",
    val transportMode: String = "Walking",
    val obstacleAvoidance: Boolean = true,
    val walletTotalAmount: Double = 0.0,
    val fallAlert: FallAlertState = FallAlertState(),
    val ownerName: String = "John Doe",
    val ownerPhotoAvatar: Int = 1
)

class AssistiveViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = AssistiveRepository(db)
    val vaultService = SecurityVaultService(application)
    val aiService = GeminiAiService(vaultService)
    val apiRouterService = ApiRouterService(application, vaultService, aiService)
    val voiceAuthManager = VoiceAuthManager(application, repository)
    val ttsManager = TtsSpeechManager(application)
    val wakeWordEngine = WakeWordEngine(application)

    // New Assistive Engines
    val fallDetectionEngine = FallDetectionEngine(application) { emergencyMsg ->
        viewModelScope.launch {
            ttsManager.hapticFail()
            ttsManager.speak("හදිසි පණිවිඩය යවන ලදී: $emergencyMsg")
        }
    }
    val currencyCounterEngine = CurrencyCounterEngine(repository)
    val lightColorAnalyzer = LightColorAnalyzer()
    val busRouteAssistant = BusRouteAssistant()
    val medicineReminderEngine = MedicineReminderEngine(repository)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val faces: StateFlow<List<FaceEntity>> = repository.allFaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val contacts: StateFlow<List<EmergencyContactEntity>> = repository.allContacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val voiceSamples: StateFlow<List<VoiceSampleEntity>> = repository.allVoiceSamples
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val medicines: StateFlow<List<MedicineReminderEntity>> = repository.allMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cachedAiResponses: StateFlow<List<AiResponseCacheEntity>> = repository.cachedResponses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize default settings, voice sample phrases, and initial engines
        viewModelScope.launch {
            loadInitialSettings()
            initializeDefaultVoicePhrases()
            medicineReminderEngine.addDefaultSampleMedicines()
            fallDetectionEngine.startMonitoring()

            // Restore latest AI response from Room DB Cache for offline continuity
            repository.getLatestCachedResponse()?.let { cached ->
                _uiState.value = _uiState.value.copy(
                    lastAiResponse = cached.responseText
                )
            }

            // Observe wallet total
            repository.walletTotal.collect { total ->
                _uiState.value = _uiState.value.copy(walletTotalAmount = total ?: 0.0)
            }
        }

        viewModelScope.launch {
            fallDetectionEngine.alertState.collect { fallState ->
                _uiState.value = _uiState.value.copy(fallAlert = fallState)
                if (fallState.isFallDetected) {
                    ttsManager.hapticWarning()
                    ttsManager.speak("ඇදවැටීමක් හඳුනාගන්නා ලදී! හදිසි පණිවිඩය යැවීමට ප්‍රථම අවලංගු කිරීමට 'නවත්වන්න' පවසන්න.")
                }
            }
        }
    }

    private suspend fun loadInitialSettings() {
        val lang = repository.getSetting("language") ?: "Sinhala"
        val speed = repository.getSetting("voiceSpeed")?.toFloatOrNull() ?: 1.0f
        val pitch = repository.getSetting("voicePitch")?.toFloatOrNull() ?: 1.0f
        val wake = repository.getSetting("wakeWord") ?: "සහායක"

        ttsManager.updateParams(speed, pitch, lang)
        _uiState.value = _uiState.value.copy(
            currentLanguage = lang,
            voiceSpeed = speed,
            voicePitch = pitch,
            wakeWord = wake
        )
    }

    private suspend fun initializeDefaultVoicePhrases() {
        val enrolledCount = repository.getEnrolledVoiceCount()
        if (enrolledCount == 0) {
            VoiceAuthManager.REQUIRED_PHRASES.forEachIndexed { index, phrase ->
                repository.saveVoiceSample(
                    VoiceSampleEntity(
                        phraseIndex = index,
                        phraseText = phrase,
                        isEnrolled = false
                    )
                )
            }
        }
    }

    fun triggerVoiceCommand(promptText: String, capturedBitmap: Bitmap? = null) {
        viewModelScope.launch {
            // Check voice authentication RBAC with biometric stream matching
            ttsManager.hapticListen()
            _uiState.value = _uiState.value.copy(activeState = AppActiveState.LISTENING)

            val pcmStream = voiceAuthManager.captureAudioStream(durationMs = 800)
            val authResult = voiceAuthManager.authenticateVoiceStream(pcmStream)
            val role = authResult.matchedRole
            _uiState.value = _uiState.value.copy(accessRole = role)

            if (role is AccessRole.Stranger) {
                ttsManager.hapticWarning()
                _uiState.value = _uiState.value.copy(
                    activeState = AppActiveState.IDLE,
                    lastAiResponse = role.message
                )
                ttsManager.speak(role.message)
                return@launch
            }

            // Valid Owner / Authorized Command
            _uiState.value = _uiState.value.copy(activeState = AppActiveState.PROCESSING)

            val promptLower = promptText.lowercase()
            val language = _uiState.value.currentLanguage

            val responseStr = when {
                // Emergency fall alert cancel
                promptLower.contains("නවත්වන්න") || promptLower.contains("stop") || promptLower.contains("cancel") -> {
                    if (_uiState.value.fallAlert.isFallDetected) {
                        fallDetectionEngine.cancelFallAlert()
                    } else {
                        "ක්‍රියාවලිය නවත්වා ඇත."
                    }
                }
                // Currency scan / wallet query
                promptLower.contains("මුදල්") || promptLower.contains("නෝට්ටු") || promptLower.contains("එකතුව") || promptLower.contains("wallet") -> {
                    val scanResult = currencyCounterEngine.processCurrencyScan(capturedBitmap, promptText, _uiState.value.walletTotalAmount)
                    scanResult.message
                }
                // Light & Color analysis
                promptLower.contains("ආලෝකය") || promptLower.contains("වර්ණය") || promptLower.contains("එළිය") || promptLower.contains("light") || promptLower.contains("color") -> {
                    val lightResult = lightColorAnalyzer.analyzeFrame(capturedBitmap)
                    lightResult.summarySpeech
                }
                // Bus route & Navigation
                promptLower.contains("බස්") || promptLower.contains("නැවතුම") || promptLower.contains("ගමනාන්තය") || promptLower.contains("bus") -> {
                    busRouteAssistant.findNearestBusStopAndRoute(promptText)
                }
                // Medicine reminders
                promptLower.contains("බෙහෙත්") || promptLower.contains("පෙති") || promptLower.contains("medicine") -> {
                    medicineReminderEngine.getDailyMedicinesSummary()
                }
                // Standard Multimodal AI Route
                else -> {
                    val result = apiRouterService.processVisionAndQuery(capturedBitmap, promptText, language)
                    result.getOrElse { error ->
                        // Room DB Cache fallback for offline functionality
                        val cached = repository.findCachedResponse(promptText)
                        if (cached != null) {
                            "[නොබැඳි Room DB Cache]: ${cached.responseText}"
                        } else {
                            "දෝෂයක් සිදු විය: ${error.localizedMessage}"
                        }
                    }
                }
            }

            // Cache AI response into Room database for offline accessibility
            if (responseStr.isNotBlank() && !responseStr.contains("දෝෂයක් සිදු විය")) {
                repository.cacheAiResponse(promptText, responseStr, language)
            }

            ttsManager.hapticConfirm()
            _uiState.value = _uiState.value.copy(
                activeState = AppActiveState.IDLE,
                lastAiResponse = responseStr
            )
            ttsManager.speak(responseStr)
        }
    }

    fun clearAiCache() {
        viewModelScope.launch {
            repository.clearAiResponseCache()
            ttsManager.speak("AI සටහන් Cache දත්ත මකාදමන ලදී.")
        }
    }


    fun cancelFallAlert() {
        val msg = fallDetectionEngine.cancelFallAlert()
        ttsManager.speak(msg)
    }

    fun addMedicine(name: String, dosage: String, timeOfDay: String) {
        viewModelScope.launch {
            repository.insertMedicine(
                MedicineReminderEntity(
                    medicineName = name,
                    dosage = dosage,
                    timeOfDay = timeOfDay,
                    isTakenToday = false
                )
            )
            ttsManager.speak("බෙහෙත් $name ලියාපදිංචි විය.")
        }
    }

    fun deleteMedicine(medicine: MedicineReminderEntity) {
        viewModelScope.launch {
            repository.deleteMedicine(medicine)
        }
    }

    fun clearWallet() {
        viewModelScope.launch {
            repository.clearWallet()
            ttsManager.speak("පසුම්බියේ එකතුව ශූන්‍ය කරන ලදී.")
        }
    }


    fun verifyPin(pinText: String): Boolean {
        val isValid = vaultService.verifyPin(pinText)
        if (isValid) {
            _uiState.value = _uiState.value.copy(isPinAuthorized = true)
            ttsManager.hapticConfirm()
        } else {
            ttsManager.hapticFail()
        }
        return isValid
    }

    fun lockPinGate() {
        _uiState.value = _uiState.value.copy(isPinAuthorized = false)
    }

    fun selectSettingsCategory(categoryIndex: Int) {
        _uiState.value = _uiState.value.copy(selectedCategory = categoryIndex)
    }

    fun updateVoiceSettings(speed: Float, pitch: Float, language: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                voiceSpeed = speed,
                voicePitch = pitch,
                currentLanguage = language
            )
            ttsManager.updateParams(speed, pitch, language)
            repository.saveSetting("voiceSpeed", speed.toString())
            repository.saveSetting("voicePitch", pitch.toString())
            repository.saveSetting("language", language)
        }
    }

    fun updateOwnerProfile(name: String, avatarId: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(ownerName = name, ownerPhotoAvatar = avatarId)
            repository.saveSetting("ownerName", name)
            repository.saveSetting("ownerPhotoAvatar", avatarId.toString())
        }
    }

    fun updateWakeWordSettings(phrase: String, sensitivity: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(wakeWord = phrase, wakeSensitivity = sensitivity)
            wakeWordEngine.configure(phrase, sensitivity)
            repository.saveSetting("wakeWord", phrase)
            repository.saveSetting("wakeSensitivity", sensitivity)
        }
    }

    fun updateAiPreferences(conciseness: String, samplingRate: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                responseConciseness = conciseness,
                sceneSamplingRate = samplingRate
            )
            repository.saveSetting("conciseness", conciseness)
            repository.saveSetting("samplingRate", samplingRate.toString())
        }
    }

    fun updateHardwarePreferences(cameraSource: String, audioOutput: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                cameraSource = cameraSource,
                audioOutputChannel = audioOutput
            )
            repository.saveSetting("cameraSource", cameraSource)
            repository.saveSetting("audioOutput", audioOutput)
        }
    }

    fun updateNavigationPreferences(transportMode: String, obstacleAvoidance: Boolean) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                transportMode = transportMode,
                obstacleAvoidance = obstacleAvoidance
            )
            repository.saveSetting("transportMode", transportMode)
            repository.saveSetting("obstacleAvoidance", obstacleAvoidance.toString())
        }
    }

    fun updateSecurityPin(oldPin: String, newPin: String): Boolean {
        if (vaultService.verifyPin(oldPin)) {
            vaultService.setPin(newPin)
            ttsManager.hapticConfirm()
            return true
        }
        ttsManager.hapticFail()
        return false
    }

    fun enrollVoiceSample(phraseIndex: Int, phraseText: String) {
        viewModelScope.launch {
            ttsManager.hapticListen()
            val audioStream = voiceAuthManager.captureAudioStream(durationMs = 1200)
            voiceAuthManager.enrollVoiceSampleFromAudioStream(
                phraseIndex = phraseIndex,
                phraseText = phraseText,
                pcmData = audioStream
            )
            ttsManager.hapticConfirm()
            ttsManager.speak("වාචික පද $phraseIndex ($phraseText) ස්වර ජෛවමිතිය සාර්ථකව ලියාපදිංචි විය.")
        }
    }

    fun addEmergencyContact(name: String, phone: String, relationship: String, isPrimary: Boolean) {
        viewModelScope.launch {
            repository.insertContact(
                EmergencyContactEntity(
                    name = name,
                    phone = phone,
                    relationship = relationship,
                    isPrimary = isPrimary
                )
            )
        }
    }

    fun deleteEmergencyContact(contact: EmergencyContactEntity) {
        viewModelScope.launch {
            repository.deleteContact(contact)
        }
    }

    fun registerFace(name: String) {
        viewModelScope.launch {
            // Simulated 128-dim face embedding
            val embedding = FloatArray(128) { (Math.random() * 2 - 1).toFloat() }
            val vecJson = embedding.joinToString(prefix = "[", postfix = "]")
            repository.insertFace(
                FaceEntity(
                    name = name,
                    embeddingJson = vecJson,
                    confidenceThreshold = 0.85f
                )
            )
            ttsManager.speak("මුහුණ $name නමින් ලියාපදිංචි විය.")
        }
    }

    fun deleteFace(face: FaceEntity) {
        viewModelScope.launch {
            repository.deleteFace(face)
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
    }
}
