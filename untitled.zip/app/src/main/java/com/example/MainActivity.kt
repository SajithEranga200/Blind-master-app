package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.PinPadDialog
import com.example.ui.screens.CategorySettingsScreen
import com.example.ui.screens.IdleLockScreen
import com.example.ui.screens.OptionsDashboardScreen
import com.example.ui.screens.SettingsDashboardScreen
import com.example.ui.theme.AssistiveAITheme
import com.example.ui.theme.DeepVoid
import com.example.ui.viewmodel.AssistiveViewModel

enum class NavigationScreen {
    IDLE_LOCK,
    SETTINGS_DASHBOARD,
    CATEGORY_SETTINGS,
    OPTIONS_DASHBOARD
}

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Permissions handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        checkAndRequestPermissions()

        setContent {
            AssistiveAITheme {
                val viewModel: AssistiveViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                val faces by viewModel.faces.collectAsStateWithLifecycle()
                val contacts by viewModel.contacts.collectAsStateWithLifecycle()
                val voiceSamples by viewModel.voiceSamples.collectAsStateWithLifecycle()
                val medicines by viewModel.medicines.collectAsStateWithLifecycle()
                val cachedAiResponses by viewModel.cachedAiResponses.collectAsStateWithLifecycle()

                var currentScreen by remember { mutableStateOf(NavigationScreen.IDLE_LOCK) }
                var showPinDialog by remember { mutableStateOf(false) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DeepVoid)
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(300)) + slideInHorizontally { width -> width / 2 } togetherWith
                                    fadeOut(animationSpec = tween(300)) + slideOutHorizontally { width -> -width / 2 }
                        },
                        label = "ScreenNavigation"
                    ) { screen ->
                        when (screen) {
                            NavigationScreen.IDLE_LOCK -> {
                                IdleLockScreen(
                                    activeState = uiState.activeState,
                                    lastAiResponse = uiState.lastAiResponse,
                                    accessRole = uiState.accessRole,
                                    wakeWord = uiState.wakeWord,
                                    walletTotal = uiState.walletTotalAmount,
                                    fallAlert = uiState.fallAlert,
                                    ownerName = uiState.ownerName,
                                    ownerPhotoAvatar = uiState.ownerPhotoAvatar,
                                    currentLanguage = uiState.currentLanguage,
                                    onCancelFallAlert = { viewModel.cancelFallAlert() },
                                    onVoiceTriggerClick = { prompt ->
                                        viewModel.triggerVoiceCommand(prompt)
                                    },
                                    onCameraScanClick = {
                                        viewModel.triggerVoiceCommand("මගේ වටපිටාවේ ඇති දේවල් විස්තර කරන්න.")
                                    },
                                    onDocumentScanClick = {
                                        viewModel.triggerVoiceCommand("මම අල්ලාගෙන සිටින ලේඛනය හෝ මුදල් නෝට්ටුව කියවන්න.")
                                    },
                                    onSettingsGateClick = {
                                        if (uiState.isPinAuthorized) {
                                            viewModel.ttsManager.speak("සැකසුම් පුවරුවට පිවිසියා")
                                            currentScreen = NavigationScreen.SETTINGS_DASHBOARD
                                        } else {
                                            viewModel.ttsManager.speak("ආරක්ෂිත PIN පියවර ඇතුළත් කරන්න")
                                            showPinDialog = true
                                        }
                                    },
                                    onOptionsClick = {
                                        viewModel.ttsManager.speak("විශේෂාංග සහ විකල්ප පුවරුවට පිවිසියා")
                                        currentScreen = NavigationScreen.OPTIONS_DASHBOARD
                                    }
                                )
                            }

                            NavigationScreen.OPTIONS_DASHBOARD -> {
                                OptionsDashboardScreen(
                                    currentLanguage = uiState.currentLanguage,
                                    onBackClick = {
                                        viewModel.ttsManager.speak("මුඛ්‍ය තිරයට පැමිණියා")
                                        currentScreen = NavigationScreen.IDLE_LOCK
                                    },
                                    onOptionSelected = { option ->
                                        viewModel.ttsManager.speak(option.titleSin + " තෝරාගත්තා")
                                        currentScreen = NavigationScreen.IDLE_LOCK
                                        option.voiceCommand?.let { cmd ->
                                            viewModel.triggerVoiceCommand(cmd)
                                        }
                                    },
                                    onNavigateToCategory = { categoryId ->
                                        viewModel.selectSettingsCategory(categoryId)
                                        viewModel.ttsManager.speak("සැකසුම් ප්‍රවර්ගයට පිවිසියා")
                                        currentScreen = NavigationScreen.CATEGORY_SETTINGS
                                    }
                                )
                            }

                            NavigationScreen.SETTINGS_DASHBOARD -> {
                                SettingsDashboardScreen(
                                    currentLanguage = uiState.currentLanguage,
                                    onCategorySelected = { categoryId ->
                                        viewModel.selectSettingsCategory(categoryId)
                                        viewModel.ttsManager.speak("සැකසුම් ප්‍රවර්ගය තෝරාගත්තා")
                                        currentScreen = NavigationScreen.CATEGORY_SETTINGS
                                    },
                                    onLockGateClick = {
                                        viewModel.lockPinGate()
                                        viewModel.ttsManager.speak("මුඛ්‍ය තිරයට පැමිණියා")
                                        currentScreen = NavigationScreen.IDLE_LOCK
                                    }
                                )
                            }

                                    NavigationScreen.CATEGORY_SETTINGS -> {
                                CategorySettingsScreen(
                                    categoryId = uiState.selectedCategory,
                                    uiState = uiState,
                                    faces = faces,
                                    contacts = contacts,
                                    voiceSamples = voiceSamples,
                                    medicines = medicines,
                                    cachedAiResponses = cachedAiResponses,
                                    onBackClick = {
                                        viewModel.ttsManager.speak("නැවත සැකසුම් පුවරුවට")
                                        currentScreen = NavigationScreen.SETTINGS_DASHBOARD
                                    },
                                    onUpdateVoiceSettings = { speed, pitch, lang ->
                                        viewModel.updateVoiceSettings(speed, pitch, lang)
                                    },
                                    onUpdateWakeWordSettings = { phrase, sens ->
                                        viewModel.updateWakeWordSettings(phrase, sens)
                                    },
                                    onUpdateAiPreferences = { conc, sampling ->
                                        viewModel.updateAiPreferences(conc, sampling)
                                    },
                                    onUpdateHardwarePreferences = { camera, audio ->
                                        viewModel.updateHardwarePreferences(camera, audio)
                                    },
                                    onUpdateNavigationPreferences = { mode, obstacle ->
                                        viewModel.updateNavigationPreferences(mode, obstacle)
                                    },
                                    onUpdateSecurityPin = { oldPin, newPin ->
                                        viewModel.updateSecurityPin(oldPin, newPin)
                                    },
                                    onEnrollVoiceSample = { index, text ->
                                        viewModel.enrollVoiceSample(index, text)
                                    },
                                    onAddEmergencyContact = { name, phone, rel, isPrimary ->
                                        viewModel.addEmergencyContact(name, phone, rel, isPrimary)
                                    },
                                    onDeleteEmergencyContact = { contact ->
                                        viewModel.deleteEmergencyContact(contact)
                                    },
                                    onRegisterFace = { name ->
                                        viewModel.registerFace(name)
                                    },
                                    onDeleteFace = { face ->
                                        viewModel.deleteFace(face)
                                    },
                                    onAddMedicine = { name, dosage, timeOfDay ->
                                        viewModel.addMedicine(name, dosage, timeOfDay)
                                    },
                                    onDeleteMedicine = { medicine ->
                                        viewModel.deleteMedicine(medicine)
                                    },
                                    onClearWallet = {
                                        viewModel.clearWallet()
                                    },
                                    onUpdateOwnerProfile = { name, avatarId ->
                                        viewModel.updateOwnerProfile(name, avatarId)
                                    },
                                    onClearAiCache = {
                                        viewModel.clearAiCache()
                                    }
                                )
                            }
                        }
                    }

                    // PIN Authorization Gate Dialog
                    if (showPinDialog) {
                        PinPadDialog(
                            onDismiss = { showPinDialog = false },
                            onPinSubmitted = { pinInput ->
                                viewModel.verifyPin(pinInput)
                            },
                            onSuccess = {
                                showPinDialog = false
                                currentScreen = NavigationScreen.SETTINGS_DASHBOARD
                            }
                        )
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }
}
