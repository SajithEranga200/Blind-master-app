package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "faces")
data class FaceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val embeddingJson: String, // Vector representation
    val confidenceThreshold: Float = 0.85f,
    val registeredTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val relationship: String,
    val isPrimary: Boolean = false
)

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "voice_samples")
data class VoiceSampleEntity(
    @PrimaryKey val phraseIndex: Int,
    val phraseText: String,
    val isEnrolled: Boolean = false,
    val audioPath: String? = null,
    val embeddingJson: String? = null
)

@Entity(tableName = "medicine_reminders")
data class MedicineReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineName: String,
    val dosage: String,
    val timeOfDay: String,
    val isTakenToday: Boolean = false
)

@Entity(tableName = "currency_transactions")
data class CurrencyTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val noteDescription: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_response_cache")
data class AiResponseCacheEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val promptQuery: String,
    val responseText: String,
    val language: String,
    val timestamp: Long = System.currentTimeMillis()
)



