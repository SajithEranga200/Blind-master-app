package com.example.data.local

import kotlinx.coroutines.flow.Flow

class AssistiveRepository(private val db: AppDatabase) {

    val allFaces: Flow<List<FaceEntity>> = db.faceDao().getAllFaces()
    val allContacts: Flow<List<EmergencyContactEntity>> = db.emergencyContactDao().getAllContacts()
    val allSettings: Flow<List<UserSettingsEntity>> = db.userSettingsDao().getAllSettings()
    val allVoiceSamples: Flow<List<VoiceSampleEntity>> = db.voiceSampleDao().getAllVoiceSamples()
    val allMedicines: Flow<List<MedicineReminderEntity>> = db.medicineReminderDao().getAllMedicines()
    val allTransactions: Flow<List<CurrencyTransactionEntity>> = db.currencyTransactionDao().getAllTransactions()
    val walletTotal: Flow<Double?> = db.currencyTransactionDao().getTotalWalletBalance()
    val cachedResponses: Flow<List<AiResponseCacheEntity>> = db.aiResponseCacheDao().getAllCachedResponses()

    suspend fun insertFace(face: FaceEntity) = db.faceDao().insertFace(face)
    suspend fun deleteFace(face: FaceEntity) = db.faceDao().deleteFace(face)

    suspend fun insertContact(contact: EmergencyContactEntity) = db.emergencyContactDao().insertContact(contact)
    suspend fun deleteContact(contact: EmergencyContactEntity) = db.emergencyContactDao().deleteContact(contact)

    suspend fun getSetting(key: String): String? = db.userSettingsDao().getValueByKey(key)
    suspend fun saveSetting(key: String, value: String) {
        db.userSettingsDao().insertSetting(UserSettingsEntity(key, value))
    }

    suspend fun saveVoiceSample(sample: VoiceSampleEntity) = db.voiceSampleDao().insertVoiceSample(sample)
    suspend fun getEnrolledVoiceCount(): Int = db.voiceSampleDao().getEnrolledCount()

    suspend fun insertMedicine(medicine: MedicineReminderEntity) = db.medicineReminderDao().insertMedicine(medicine)
    suspend fun deleteMedicine(medicine: MedicineReminderEntity) = db.medicineReminderDao().deleteMedicine(medicine)
    suspend fun updateMedicineTaken(id: Long, taken: Boolean) = db.medicineReminderDao().updateTakenState(id, taken)

    suspend fun addCurrencyTransaction(amount: Double, description: String) {
        db.currencyTransactionDao().insertTransaction(CurrencyTransactionEntity(amount = amount, noteDescription = description))
    }
    suspend fun clearWallet() = db.currencyTransactionDao().clearWallet()

    suspend fun cacheAiResponse(prompt: String, response: String, language: String) {
        db.aiResponseCacheDao().insertResponse(
            AiResponseCacheEntity(
                promptQuery = prompt,
                responseText = response,
                language = language
            )
        )
    }

    suspend fun findCachedResponse(query: String): AiResponseCacheEntity? {
        return db.aiResponseCacheDao().findCachedResponse(query)
            ?: db.aiResponseCacheDao().getLatestResponse()
    }

    suspend fun getLatestCachedResponse(): AiResponseCacheEntity? {
        return db.aiResponseCacheDao().getLatestResponse()
    }

    suspend fun clearAiResponseCache() {
        db.aiResponseCacheDao().clearCache()
    }
}

