package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FaceDao {
    @Query("SELECT * FROM faces ORDER BY registeredTimestamp DESC")
    fun getAllFaces(): Flow<List<FaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFace(face: FaceEntity): Long

    @Delete
    suspend fun deleteFace(face: FaceEntity)

    @Query("DELETE FROM faces WHERE id = :id")
    suspend fun deleteFaceById(id: Long)
}

@Dao
interface EmergencyContactDao {
    @Query("SELECT * FROM emergency_contacts ORDER BY isPrimary DESC, name ASC")
    fun getAllContacts(): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: EmergencyContactEntity): Long

    @Delete
    suspend fun deleteContact(contact: EmergencyContactEntity)
}

@Dao
interface UserSettingsDao {
    @Query("SELECT * FROM user_settings")
    fun getAllSettings(): Flow<List<UserSettingsEntity>>

    @Query("SELECT value FROM user_settings WHERE `key` = :key")
    suspend fun getValueByKey(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: UserSettingsEntity)
}

@Dao
interface VoiceSampleDao {
    @Query("SELECT * FROM voice_samples ORDER BY phraseIndex ASC")
    fun getAllVoiceSamples(): Flow<List<VoiceSampleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoiceSample(sample: VoiceSampleEntity)

    @Query("SELECT COUNT(*) FROM voice_samples WHERE isEnrolled = 1")
    suspend fun getEnrolledCount(): Int
}

@Dao
interface MedicineReminderDao {
    @Query("SELECT * FROM medicine_reminders ORDER BY id DESC")
    fun getAllMedicines(): Flow<List<MedicineReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: MedicineReminderEntity): Long

    @Delete
    suspend fun deleteMedicine(medicine: MedicineReminderEntity)

    @Query("UPDATE medicine_reminders SET isTakenToday = :taken WHERE id = :id")
    suspend fun updateTakenState(id: Long, taken: Boolean)
}

@Dao
interface CurrencyTransactionDao {
    @Query("SELECT * FROM currency_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<CurrencyTransactionEntity>>

    @Query("SELECT SUM(amount) FROM currency_transactions")
    fun getTotalWalletBalance(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: CurrencyTransactionEntity): Long

    @Query("DELETE FROM currency_transactions")
    suspend fun clearWallet()
}

@Dao
interface AiResponseCacheDao {
    @Query("SELECT * FROM ai_response_cache ORDER BY timestamp DESC")
    fun getAllCachedResponses(): Flow<List<AiResponseCacheEntity>>

    @Query("SELECT * FROM ai_response_cache WHERE LOWER(promptQuery) LIKE '%' || LOWER(:query) || '%' ORDER BY timestamp DESC LIMIT 1")
    suspend fun findCachedResponse(query: String): AiResponseCacheEntity?

    @Query("SELECT * FROM ai_response_cache ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestResponse(): AiResponseCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResponse(response: AiResponseCacheEntity): Long

    @Query("DELETE FROM ai_response_cache")
    suspend fun clearCache()
}


