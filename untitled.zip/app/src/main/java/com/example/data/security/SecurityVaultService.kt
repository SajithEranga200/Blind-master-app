package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import com.example.BuildConfig

class SecurityVaultService(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("assistive_vault_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN_HASH = "vault_pin_hash"
        private const val KEY_GEMINI_KEY = "vault_gemini_api_key"
        private const val KEY_AZURE_KEY = "vault_azure_api_key"
        private const val KEY_MAPS_KEY = "vault_maps_api_key"
        private const val DEFAULT_PIN = "1234"
    }

    init {
        // Initialize default PIN hash if not present
        if (!prefs.contains(KEY_PIN_HASH)) {
            setPin(DEFAULT_PIN)
        }
    }

    private fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_PIN_HASH, "") ?: ""
        return storedHash == hashString(pin)
    }

    fun setPin(newPin: String) {
        prefs.edit().putString(KEY_PIN_HASH, hashString(newPin)).apply()
    }

    fun getGeminiApiKey(): String {
        val saved = prefs.getString(KEY_GEMINI_KEY, "") ?: ""
        if (saved.isNotBlank()) return saved
        // Fallback to BuildConfig injected from .env / Secrets panel
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    fun saveGeminiApiKey(key: String) {
        prefs.edit().putString(KEY_GEMINI_KEY, key).apply()
    }

    fun getAzureApiKey(): String {
        return prefs.getString(KEY_AZURE_KEY, "") ?: ""
    }

    fun saveAzureApiKey(key: String) {
        prefs.edit().putString(KEY_AZURE_KEY, key).apply()
    }

    fun getMapsApiKey(): String {
        return prefs.getString(KEY_MAPS_KEY, "") ?: ""
    }

    fun saveMapsApiKey(key: String) {
        prefs.edit().putString(KEY_MAPS_KEY, key).apply()
    }
}
