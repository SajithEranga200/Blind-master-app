package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        FaceEntity::class,
        EmergencyContactEntity::class,
        UserSettingsEntity::class,
        VoiceSampleEntity::class,
        MedicineReminderEntity::class,
        CurrencyTransactionEntity::class,
        AiResponseCacheEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun faceDao(): FaceDao
    abstract fun emergencyContactDao(): EmergencyContactDao
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun voiceSampleDao(): VoiceSampleDao
    abstract fun medicineReminderDao(): MedicineReminderDao
    abstract fun currencyTransactionDao(): CurrencyTransactionDao
    abstract fun aiResponseCacheDao(): AiResponseCacheDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "assistive_ai_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
