package com.example.data.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.data.security.SecurityVaultService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiAiService(private val vaultService: SecurityVaultService) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun analyzeImageAndPrompt(
        bitmap: Bitmap?,
        userPrompt: String,
        language: String = "Sinhala"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = vaultService.getGeminiApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API Key missing in Secrets / Vault Settings"))
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        try {
            val partsArray = JSONArray()

            // System instructions context for high Sinhala accuracy
            val sysContext = if (language.equals("Sinhala", ignoreCase = true)) {
                """
                ඔබ දෘශ්‍යබාධිත පුද්ගලයන් සඳහා වන විශේෂිත AI සහායකයා වේ (Assistive Vision AI).
                ඔබගේ ප්‍රධානම කර්තව්‍යය වන්නේ පරිශීලකයා අසන ප්‍රශ්න සහ ලබා දෙන දෘශ්‍ය/පින්තූර පිළිබඳව ඉතා නිවැරදි, ස්වාභාවික, ග්‍රාම්‍ය නොවන සුමට සිංහල භාෂාවෙන් (High Accuracy Sinhala) පිළිතුරු සැපයීමයි.

                සිංහල භාෂාවේ නිවැරදිතාවය සඳහා අනිවාර්ය රීති:
                1. සියලුම පිළිතුරු නිවැරදි සිංහල අක්ෂර වින්‍යාසයෙන් හා වාක්‍ය රචනයෙන් පමණක් සපයන්න.
                2. ඉංග්‍රීසි වචන සෘජුව පරිවර්තනය නොකර, ශ්‍රී ලාංකේය සංදර්භයට ගැලපෙන පැහැදිලි සිංහල වචන භාවිතා කරන්න.
                3. දිශාවන් (වම්පස, දකුණුපස, ඉදිරියෙන්, උඩ, යට), දුර ප්‍රමාණයන් (මීටර්, අඩි), සහ මුදල් අගයන් (රුපියල්) පැහැදිලිව සිංහලෙන් දක්වන්න.
                4. විස්තරය කෙටි, සරල, සහ හඬ සංස්ලේෂකය (Text-To-Speech Engine) මගින් කියවීමට පහසු වන සේ සකසන්න.
                5. අනවශ්‍ය සංකේත, මාර්ක්ඩවුන් (Markdown) හෝ ඉංග්‍රීසි අකුරු මිශ්‍ර නොකරන්න.
                """.trimIndent()
            } else {
                "You are an AI assistant for a visually impaired user. Provide clear, concise, highly accurate, safety-focused descriptions."
            }

            partsArray.put(JSONObject().put("text", "$sysContext\n\nUser Query: $userPrompt"))

            if (bitmap != null) {
                val byteArrayOutputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 75, byteArrayOutputStream)
                val imageBytes = byteArrayOutputStream.toByteArray()
                val base64Image = Base64.encodeToString(imageBytes, Base64.NO_WRAP)

                val inlineDataObj = JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64Image)
                }
                partsArray.put(JSONObject().put("inlineData", inlineDataObj))
            }

            val contentObj = JSONObject().put("parts", partsArray)
            val contentsArray = JSONArray().put(contentObj)

            val requestBodyJson = JSONObject().apply {
                put("contents", contentsArray)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.2)
                    put("maxOutputTokens", 512)
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP Error ${response.code}: $responseStr"))
                }

                val jsonResp = JSONObject(responseStr)
                val candidates = jsonResp.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val textResult = parts.getJSONObject(0).optString("text", "")
                        return@withContext Result.success(textResult)
                    }
                }
                Result.success("සමාවෙන්න, පැහැදිලි පිළිතුරක් ලබා ගැනීමට නොහැකි විය.")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun quickTextQuery(query: String, language: String = "Sinhala"): Result<String> {
        return analyzeImageAndPrompt(null, query, language)
    }
}
